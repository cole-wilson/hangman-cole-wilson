# Hangman
Test of shipsnake with jasmin-30/Hangman gh project


### Installation
##### Pip:
run `pip3 install hangman-cole-wilson`

### Usage
### Contributors
 - @jasmin-30
### Contact
<jasmin-30cole@colewilson.xyz>